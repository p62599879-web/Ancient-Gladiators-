@echo off
setlocal
chcp 65001 >nul
cd /d "%~dp0"
echo ==============================================
echo Ancient Gladiators - NeoForge 1.21.1 builder
echo ==============================================
where java >nul 2>nul
if errorlevel 1 (
  echo ОШИБКА: Java не найдена. Установи JDK 21: https://adoptium.net/temurin/releases/?version=21
  pause
  exit /b 1
)
java -version 2>&1 | findstr /C:"21." >nul
if errorlevel 1 (
  echo ОШИБКА: нужна именно Java 21. Проверь команду java -version.
  pause
  exit /b 1
)
set "GRADLE_VERSION=8.10.2"
set "GRADLE_HOME=%~dp0.tools\gradle-%GRADLE_VERSION%"
set "GRADLE_EXE=%GRADLE_HOME%\bin\gradle.bat"
if not exist "%GRADLE_EXE%" (
  echo Gradle не найден. Скачиваю Gradle %GRADLE_VERSION% автоматически...
  if not exist "%~dp0.tools" mkdir "%~dp0.tools"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%~dp0.tools\gradle-%GRADLE_VERSION%-bin.zip'"
  if errorlevel 1 (
    echo Не удалось скачать Gradle. Проверь интернет и запусти build.bat ещё раз.
    pause
    exit /b 1
  ) 
  echo Распаковываю Gradle...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%~dp0.tools\gradle-%GRADLE_VERSION%-bin.zip' -DestinationPath '%~dp0.tools' -Force"
  if errorlevel 1 (
    echo Не удалось распаковать Gradle.
    pause
    exit /b 1
  )
)
echo Запускаю сборку мода. Первый запуск может занять несколько минут...
call "%GRADLE_EXE%" --no-daemon build
if errorlevel 1 (
  echo.
  echo СБОРКА НЕ УДАЛАСЬ. Сфотографируй последние строки ошибки и пришли мне.
  pause
  exit /b 1
)
echo.
echo ==============================================
echo ГОТОВО! Ищи .jar в папке build\libs\
echo ==============================================
explorer "%~dp0build\libs"
pause
