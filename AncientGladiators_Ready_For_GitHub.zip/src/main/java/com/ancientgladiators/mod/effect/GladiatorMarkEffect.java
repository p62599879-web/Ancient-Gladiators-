package com.ancientgladiators.mod.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/**
 * The Gladiator Mark is an effect, not an inventory item.
 * Its amplifier represents six ranks: I through VI (amplifier 0 through 5).
 * Combat bonuses and boss-scaling rules will be added with their gameplay systems.
 */
public final class GladiatorMarkEffect extends MobEffect {
    public GladiatorMarkEffect() {
        super(MobEffectCategory.NEUTRAL, 0x9B35D5);
    }
}
