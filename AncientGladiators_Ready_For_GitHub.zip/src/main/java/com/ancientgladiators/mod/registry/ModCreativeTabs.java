package com.ancientgladiators.mod.registry;

import com.ancientgladiators.mod.AncientGladiators;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, AncientGladiators.MOD_ID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> ANCIENT_GLADIATORS =
            TABS.register("ancient_gladiators", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.ancient_gladiators"))
                    .icon(() -> ModItems.ANCIENT_HANDLE.get().getDefaultInstance())
                    .displayItems((parameters, output) -> {
                        output.accept(ModItems.ANCIENT_HANDLE.get());
                        output.accept(ModItems.ANCIENT_SWORD.get());
                        output.accept(ModItems.ANCIENT_AXE.get());
                        output.accept(ModItems.ANCIENT_TRIDENT.get());
                        output.accept(ModItems.ANCIENT_HAMMER.get());
                        output.accept(ModItems.ANCIENT_SPEAR.get());
                        output.accept(ModItems.ANCIENT_KATANA.get());
                        output.accept(ModItems.RUIN_SEAL.get());
                        output.accept(ModItems.MIRROR_SEAL.get());
                        output.accept(ModItems.ASH_SEAL.get());
                        output.accept(ModItems.CURSE_CONTRACT.get());
                        output.accept(ModItems.TRAINING_HALL_KEY.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
