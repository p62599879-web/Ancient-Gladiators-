package com.ancientgladiators.mod.registry;

import com.ancientgladiators.mod.AncientGladiators;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS =
            DeferredRegister.createItems(AncientGladiators.MOD_ID);

    public static final DeferredItem<Item> ANCIENT_SWORD = ITEMS.register("ancient_sword", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> ANCIENT_AXE = ITEMS.register("ancient_axe", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> ANCIENT_TRIDENT = ITEMS.register("ancient_trident", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> ANCIENT_HAMMER = ITEMS.register("ancient_hammer", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> ANCIENT_SPEAR = ITEMS.register("ancient_spear", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> ANCIENT_KATANA = ITEMS.register("ancient_katana", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> ANCIENT_HANDLE = ITEMS.register("ancient_handle", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> CURSE_CONTRACT = ITEMS.register("curse_contract", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> TRAINING_HALL_KEY = ITEMS.register("training_hall_key", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> RUIN_SEAL = ITEMS.register("ruin_seal", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> MIRROR_SEAL = ITEMS.register("mirror_seal", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<Item> ASH_SEAL = ITEMS.register("ash_seal", () -> new Item(new Item.Properties().stacksTo(1)));

    private ModItems() {}
}
