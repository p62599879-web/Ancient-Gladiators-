package com.ancientgladiators.mod.registry;

import com.ancientgladiators.mod.AncientGladiators;
import com.ancientgladiators.mod.effect.GladiatorMarkEffect;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

public final class ModEffects {
    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(Registries.MOB_EFFECT, AncientGladiators.MOD_ID);

    public static final DeferredHolder<MobEffect, MobEffect> GLADIATOR_MARK =
            EFFECTS.register("gladiator_mark", GladiatorMarkEffect::new);

    private ModEffects() {}
}
