package com.ancientgladiators.mod;

import com.ancientgladiators.mod.registry.ModCreativeTabs;
import com.ancientgladiators.mod.registry.ModItems;
import com.ancientgladiators.mod.registry.ModEffects;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(AncientGladiators.MOD_ID)
public final class AncientGladiators {
    public static final String MOD_ID = "ancient_gladiators";

    public AncientGladiators() {
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModItems.ITEMS.register(modEventBus);
        ModEffects.EFFECTS.register(modEventBus);
        ModCreativeTabs.TABS.register(modEventBus);
    }
}
