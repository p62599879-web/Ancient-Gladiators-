МЕЧ — ИСХОДНЫЕ ФАЙЛЫ И РЕФЕРЕНСЫ

В папке docs/sword_reference лежат предоставленные пользователем файлы меча:
- AncientGladiators_Sword_Textured.bbmodel — исходная модель Blockbench;
- AncientGladiators_Sword_Texture.png — текстура;
- AncientGladiators_Sword_Texture_Preview.png — превью.

ВАЖНО: эти файлы сохранены в архиве как исходные материалы. Они ещё НЕ преобразованы
и НЕ подключены к игровому рендереру Minecraft. Этот архив содержит исходный проект,
а не собранный .jar.
