# Ancient Gladiators — стартовый проект мода

Это **исходный проект первой заготовки**, а не законченная реализация всей концепции. В нём зарегистрированы предметы для шести видов древнего оружия, рукоять, эффект «Клеймо гладиатора», контракт, ключ тренировочного зала и три печати. Мод пока не реализует боссов, боевую механику оружия, клеймо мира, превращение брони или тренировочный зал — эти системы нужно добавлять поэтапно и тестировать.

## Требования
- Minecraft Java Edition **1.21.1**
- NeoForge **21.1.x**
- JDK **21**
- IntelliJ IDEA (рекомендуется)

## Как открыть и собрать
1. Распакуй архив в отдельную папку.
2. Открой папку проекта в IntelliJ IDEA как Gradle-проект.
3. Укажи JDK 21 для Gradle и дождись синхронизации.
4. Запусти Gradle-задачу `runClient` для тестового клиента.
5. Для сборки запусти `build`. JAR появится в `build/libs`.

В архиве нет Gradle Wrapper (`gradlew` / `gradlew.bat`), поэтому для сборки нужен установленный Gradle 8.10.2 или совместимый Gradle 8.x. Java 21 обязательна.

В Windows из терминала в папке проекта можно использовать:
```powershell
.\gradlew.bat runClient
.\gradlew.bat build
```
Если Gradle wrapper не появился в архиве/IDE не распознала его, создай wrapper командой `gradle wrapper` при установленном Gradle либо открой проект через совместимый NeoForge MDK.

## Где предметы
После успешного запуска можно получить предметы через творческий инвентарь, вкладку Ancient Gladiators, если клиент автоматически создал её не будет доступен, можно использовать команды выдачи по ID:
- `ancient_gladiators:ancient_sword`
- `ancient_gladiators:ancient_axe`
- `ancient_gladiators:ancient_trident`
- `ancient_gladiators:ancient_hammer`
- `ancient_gladiators:ancient_spear`
- `ancient_gladiators:ancient_katana`
- `ancient_gladiators:ancient_handle`
- `ancient_gladiators:curse_contract`
- `ancient_gladiators:training_hall_key`
- `ancient_gladiators:ruin_seal`
- `ancient_gladiators:mirror_seal`
- `ancient_gladiators:ash_seal`

Клеймо — **эффект**, а не предмет. Его можно выдать командой: `/effect give @s ancient_gladiators:gladiator_mark 999999 0 true`. Усилитель `0` соответствует уровню I, `1` — II, … `5` — VI. Отдельная система автоматического повышения уровня и боевых бонусов пока не реализована.

Пример выдачи рукояти: `/give @s ancient_gladiators:ancient_handle`

## Важно
Это первая техническая основа для дальнейшей разработки. Предметы пока в основном являются заготовками и используют временные ванильные иконки. Не устанавливай проект в основной мир без резервной копии.
